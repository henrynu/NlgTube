var urlmd = {"FAQ":"https://raw.githubusercontent.com/henrynu/NuLagoon/master/FAQ.md",
"Guide":"https://raw.githubusercontent.com/henrynu/NuLagoon/master/Fund%20Deposit%20and%20Withdraw%20Guide.md",
"Risk":"https://raw.githubusercontent.com/henrynu/NuLagoon/master/Risk%20Disclosure.md",
"TermA":"https://raw.githubusercontent.com/henrynu/NuLagoon/master/Terms%20of%20Pool%20A.md",
"TermCD":"https://raw.githubusercontent.com/henrynu/NuLagoon/master/Terms%20of%20Pool%20C%20%26%20D.md",
"MotionNLG":"https://raw.githubusercontent.com/henrynu/NuLagoon/master/Motion%20creating%20NuLagoon.md",
"MotionFEE":"https://raw.githubusercontent.com/henrynu/NuLagoon/master/Motion%20capping%20NuLagoon%20Fees.md",
};
jpath = 'https://raw.githubusercontent.com/henrynu/NuLagoon/master/res/data/';